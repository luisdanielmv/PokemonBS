export { default as Nav } from './common/nav';
export { default as Home } from './home';
export { default as Details } from './details';